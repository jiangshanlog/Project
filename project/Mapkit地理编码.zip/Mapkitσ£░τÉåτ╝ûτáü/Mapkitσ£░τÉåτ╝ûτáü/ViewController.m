//
//  ViewController.m
//  Mapkit地理编码
//
//  Created by QG on 16/1/29.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "MapAnnotation.h"


@interface ViewController ()<MKMapViewDelegate>{
    double latitude;
    double longitude;
}
//地址
@property (weak, nonatomic) IBOutlet UITextField *addressTextField;
//经度
@property (weak, nonatomic) IBOutlet UITextField *longitudeTextField;
//纬度
@property (weak, nonatomic) IBOutlet UITextField *latitudeTextField;

@property (weak, nonatomic) IBOutlet MKMapView *mapview;





@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置代理
        self.mapview.delegate = self;
}

//地理编码
- (IBAction)genocoder:(id)sender {
    //创建编码对象
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
    //判断是否为空
    if (self.addressTextField.text.length ==0) {
        return;
    }
    [geocoder geocodeAddressString:self.addressTextField.text completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (error!=nil || placemarks.count==0) {
            return ;
        }
        //创建placemark对象
        CLPlacemark *placemark=[placemarks firstObject];
        //赋值经度
        self.longitudeTextField.text =[NSString stringWithFormat:@"%f",placemark.location.coordinate.longitude];
        longitude = placemark.location.coordinate.longitude;
        //赋值纬度
        self.latitudeTextField.text=[NSString stringWithFormat:@"%f",placemark.location.coordinate.latitude];
        latitude = placemark.location.coordinate.latitude;
            NSLog(@"%f,%f",latitude,longitude);
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(10.79871, 106.73293);
        MapAnnotation *annotation = [[MapAnnotation alloc] init];
        annotation.coordinate = coordinate;
        annotation.title = @"设备当前的位置";
        [self.mapview addAnnotation:annotation];
        [self.mapview setRegion:MKCoordinateRegionMakeWithDistance(coordinate, 500, 500)];
    }];

    
}
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    MKPinAnnotationView *annotationView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MapSample"];
    
    annotationView.canShowCallout = YES;
    
    return annotationView;
}

@end
