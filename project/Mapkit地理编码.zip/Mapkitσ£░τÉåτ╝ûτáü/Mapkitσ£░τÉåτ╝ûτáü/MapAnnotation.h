//
//  MapAnnotation.h
//  Mapkit地理编码
//
//  Created by QG on 16/2/1.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <MapKit/MapKit.h>
@interface MapAnnotation : NSObject<MKAnnotation>
@property (nonatomic) CLLocationCoordinate2D coordinate;

@property (nonatomic, copy) NSString *title;
@end
