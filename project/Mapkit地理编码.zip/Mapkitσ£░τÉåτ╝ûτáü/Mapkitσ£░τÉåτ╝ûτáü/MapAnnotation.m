//
//  MapAnnotation.m
//  Mapkit地理编码
//
//  Created by QG on 16/2/1.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "MapAnnotation.h"

@implementation MapAnnotation

@end
