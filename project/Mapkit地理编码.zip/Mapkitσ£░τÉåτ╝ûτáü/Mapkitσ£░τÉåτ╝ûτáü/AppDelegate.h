//
//  AppDelegate.h
//  Mapkit地理编码
//
//  Created by QG on 16/1/29.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

