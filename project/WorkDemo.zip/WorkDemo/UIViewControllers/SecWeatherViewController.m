//
//  SecWeatherViewController.m
//  WorkDemo
//
//  Created by QG on 16/1/4.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "SecWeatherViewController.h"
#import "WeatherViewController.h"
@interface SecWeatherViewController (){
    WeatherViewController *weather;
}

@end

@implementation SecWeatherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UISwipeGestureRecognizer *swip = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipclick)];
    swip.direction = UISwipeGestureRecognizerDirectionDown;
    [self.view addGestureRecognizer:swip];
}
- (void)swipclick{
    [self dismissViewControllerAnimated:YES completion:^{}];

}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

@end
