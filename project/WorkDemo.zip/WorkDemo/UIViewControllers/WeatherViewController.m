//
//  WeatherViewController.m
//  WorkDemo
//
//  Created by QG on 16/1/4.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "WeatherViewController.h"
#import "AppDelegate.h"
#import "SecWeatherViewController.h"
@interface WeatherViewController (){
    SecWeatherViewController *sec;
}

@end

@implementation WeatherViewController

- (void)viewDidAppear:(BOOL)animated{
    UIColor * color = [UIColor whiteColor];
    
    //这里我们设置的是颜色
    NSDictionary * dict = [NSDictionary dictionaryWithObject:color forKey:NSForegroundColorAttributeName];
    
    self.navigationController.navigationBar.titleTextAttributes = dict;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    ILBarButtonItem *btn = [ILBarButtonItem barItemWithTitle:@"go" target:self action:@selector(goclick)];
    self.navigationItem.leftBarButtonItem = btn;
    UISwipeGestureRecognizer *swip = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swip)];
    swip.direction = UISwipeGestureRecognizerDirectionUp;
    [self.view addGestureRecognizer:swip];
}
- (void)swip{
    sec = [[SecWeatherViewController alloc]init];
    [self presentViewController:sec animated:YES completion:^{}];
    
}
- (void)goclick{
    AppDelegate *delegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    YRSideViewController *sideViewController=[delegate sideViewController];
    [sideViewController showLeftViewController:true];
    
}

@end
