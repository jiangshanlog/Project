//
//  Header.h
//  WorkDemo
//
//  Created by QG on 15/12/29.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#ifndef Header_h
#define Header_h

#import "ILBarButtonItem.h"
#import <UIView+AutoLayout.h>
#define height_screen [UIScreen mainScreen].bounds.size.height
#define width_screen [UIScreen mainScreen].bounds.size.width

#define fitWidth [UIScreen mainScreen].bounds.size.width/414
#define fitHeight [UIScreen mainScreen].bounds.size.height/736
#endif /* Header_h */
