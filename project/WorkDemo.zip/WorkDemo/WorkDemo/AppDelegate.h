//
//  AppDelegate.h
//  WorkDemo
//
//  Created by QG on 15/12/29.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YRSideViewController.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong,nonatomic) YRSideViewController *sideViewController;


@end

