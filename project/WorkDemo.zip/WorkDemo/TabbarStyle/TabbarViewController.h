//
//  TabbarViewController.h
//  TabBarSDK
//
//  Created by QG on 15/12/25.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabbarViewController : UITabBarController

#pragma Tabbar with Image and Title
- (void)TabBarControllerWithViewController:(UIViewController *)vc Title:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectedImage titleColor:(UIColor *)colorTitle titleSelectColor:(UIColor *)selectedTitle;
#pragma Tabbar with Image
- (void)TabBarControllerWithViewController:(UIViewController *)vc Title:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectedImage;

@end
