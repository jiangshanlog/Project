//
//  TabbarViewController.m
//  TabBarSDK
//
//  Created by QG on 15/12/25.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "TabbarViewController.h"
#import "WeatherViewController.h"
#import "SecViewController.h"
#import "SettingTableViewController.h"

@interface TabbarViewController ()

@end

@implementation TabbarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initWithTabbar];
}


- (void)initWithTabbar{
    
    WeatherViewController *weather = [[WeatherViewController alloc]init];
    [self TabBarControllerWithViewController:weather Title:@"聊天" image:@"home_icon_like_normal" selectedImage:@"home_icon_like_click" titleColor:[UIColor grayColor] titleSelectColor:[UIColor redColor]];
    
    SecViewController *sec = [[SecViewController alloc]init];
    [self TabBarControllerWithViewController:sec Title:@"空间" image:@"kongjian" selectedImage:@"kongjian_click" titleColor:[UIColor grayColor] titleSelectColor:[UIColor blueColor]];
    
    SettingTableViewController *set = [[SettingTableViewController alloc]init];
    [self TabBarControllerWithViewController:set Title:@"设置" image:@"pengyouquan" selectedImage:@"pengyouquan_click" titleColor:[UIColor grayColor] titleSelectColor:[UIColor orangeColor]];

}

- (void)TabBarControllerWithViewController:(UIViewController *)vc Title:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectedImage titleColor:(UIColor *)colorTitle titleSelectColor:(UIColor *)selectedTitle{
    //设置tabBarItem的标签
    vc.tabBarItem.title = title;
    //设置Item的图片，后者为取消杯系统渲染，还原原图
    vc.tabBarItem.image = [[UIImage imageNamed:imageName]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    //设置Item被点击之后的图片，后者也是取消被系统渲染,
    vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
//    //设置随机颜色，
//    vc.view.backgroundColor = [UIColor colorWithRed:arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1.0];
    
    //2.取消文字的渲染效果
    NSMutableDictionary *dic=[NSMutableDictionary dictionary];
    dic[NSForegroundColorAttributeName]=selectedTitle;
    [vc.tabBarItem setTitleTextAttributes:dic forState:UIControlStateSelected];
    dic[NSForegroundColorAttributeName]=colorTitle;
    [vc.tabBarItem setTitleTextAttributes:dic forState:UIControlStateNormal];
    
    vc.title = title;
    
    //自定义的Navigation
    UINavigationController *na = [[UINavigationController alloc]initWithRootViewController:vc];
    
    //添加子控制试图
    [self addChildViewController:na];


}


- (void)TabBarControllerWithViewController:(UIViewController *)vc Title:(NSString *)title image:(NSString *)imageName selectedImage:(NSString *)selectedImage{
    //设置tabBarItem的标签
    vc.tabBarItem.title = title;
    //设置Item的图片，后者为取消杯系统渲染，还原原图
    vc.tabBarItem.image = [[UIImage imageNamed:imageName]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    //设置Item被点击之后的图片，后者也是取消被系统渲染,
    vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    

    vc.title = title;
    
    
    //自定义的Navigation
    UINavigationController *na = [[UINavigationController alloc]initWithRootViewController:vc];
    
    //添加子控制试图
    [self addChildViewController:na];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
