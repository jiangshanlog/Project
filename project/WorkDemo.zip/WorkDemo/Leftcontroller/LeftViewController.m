//
//  LeftViewController.m
//  WorkDemo
//
//  Created by QG on 15/12/29.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "LeftViewController.h"
#import "ILBarButtonItem.h"
@interface LeftViewController ()<UITableViewDataSource,UITableViewDelegate>{
    NSArray *array;
    UITableView *table;
    
}

@end

@implementation LeftViewController
- (void)viewWillAppear:(BOOL)animated{
    table.backgroundColor = [UIColor clearColor];
}
- (void)viewDidLoad {
    [super viewDidLoad];
   [self initWithNavigationItem];
    [self initWithBackgroundImage];
    [self initWithTableView];
}

- (void)initWithNavigationItem{
    ILBarButtonItem *additem = [ILBarButtonItem barItemWithImage:[UIImage imageNamed:@"11"] selectedImage:[UIImage imageNamed:@"112"] target:self action:@selector(additemclick)];
    self.navigationItem.rightBarButtonItem = additem;
}

- (void)initWithBackgroundImage{
    UIImageView *imageview = [[UIImageView alloc] initWithFrame:self.view.bounds];
    imageview.image =[UIImage imageNamed:@"LeftVCIcon2"];
    [self.view addSubview:imageview];
}

- (void)initWithTableView{
    table = [[UITableView alloc]init];
    table.delegate = self;
    table.dataSource = self;
    //取消分割线
    table.separatorStyle = UITableViewCellSeparatorStyleNone;

//    [self initWithTableHeaderView];
    [self.view addSubview:table];
    [table autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(70, 0, 70, 185)];
    
    array = [NSArray arrayWithObjects:@"哈哈喽1",
                      @"哈哈喽2",
                      @"哈哈喽3",
                      @"哈哈喽4",
                      @"哈哈喽5",
                      @"哈哈喽6",
                      @"哈哈喽7", nil];
    
}


- (void)initWithTableHeaderView{
    UIView *HeaderView = [[UIView alloc]init];
    HeaderView.backgroundColor = [UIColor orangeColor];
    HeaderView.frame = CGRectMake(0, 0, table.bounds.size.width, 200*fitHeight);
    table.tableHeaderView = HeaderView;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return array.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *str=@"cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if(cell==nil){
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:str];
    }
    cell .backgroundColor = [ UIColor clearColor];
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.text = array[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60*fitWidth;
}

- (void)additemclick{
    NSLog(@"11");
}

@end
