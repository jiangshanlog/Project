//
//  AppDelegate.m
//  Navigation
//
//  Created by QG on 15/12/23.
//  Copyright © 2015年 Johnson. All rights reserved.
//



#import <UIKit/UIKit.h>

@interface ILBarButtonItem : UIBarButtonItem


+ (ILBarButtonItem *)barItemWithImage:(UIImage*)image
                        selectedImage:(UIImage*)selectedImage
                               target:(id)target
                               action:(SEL)action;

+ (ILBarButtonItem *)barItemWithTitle:(NSString *)title target:(id)target action:(SEL)action;


@end
