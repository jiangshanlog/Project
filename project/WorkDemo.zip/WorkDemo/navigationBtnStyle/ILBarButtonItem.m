//
//  AppDelegate.m
//  Navigation
//
//  Created by QG on 15/12/23.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "ILBarButtonItem.h"

@interface ILBarButtonItem() 
@end

@implementation ILBarButtonItem

#pragma mark  按钮图片添加
- (id)initWithImage:(UIImage *)image
      selectedImage:(UIImage *)selectedImage
             target:(id)target action:(SEL)action {
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake(0.0f, 0.0f, 30.0f, 30.0f)];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    [btn setImage:image forState:UIControlStateNormal];
    [btn setImage:selectedImage forState:UIControlStateHighlighted];

    self = [[ILBarButtonItem alloc] initWithCustomView:btn];



    return self;
}


#pragma mark  按钮文字添加
- (instancetype)initWithtitle:(NSString *)title target:(id)target action:(SEL)action {
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake(0.0f, 0.0f, 40.0f, 30.0f)];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:title forState:UIControlStateNormal];
    
    self = [[ILBarButtonItem alloc] initWithCustomView:btn];
    

    
    return self;
}

#pragma mark  调用按钮图片类方法
+ (ILBarButtonItem *)barItemWithImage:(UIImage*)image
                        selectedImage:(UIImage*)selectedImage
                               target:(id)target
                               action:(SEL)action
{
    return [[ILBarButtonItem alloc] initWithImage:image
                                    selectedImage:selectedImage
                                           target:target
                                           action:action];
}
#pragma mark    调用按钮文字类方法
+ (ILBarButtonItem *)barItemWithTitle:(NSString *)title target:(id)target action:(SEL)action
{
    return [[ILBarButtonItem alloc]initWithtitle:title target:target action:action];
}



@end
