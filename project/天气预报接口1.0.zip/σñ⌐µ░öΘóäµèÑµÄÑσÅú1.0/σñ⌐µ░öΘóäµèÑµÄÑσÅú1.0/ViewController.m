//
//  ViewController.m
//  天气预报接口1.0
//
//  Created by QG on 15/12/30.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "ViewController.h"
#import <ASIHTTPRequest/ASIHTTPRequest.h>
#import "IdModel.h"
#import "SecViewController.h"
#import "ThirdViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self weathercity];

}

- (void)weather{
        IdModel *_id = [IdModel initObjectID];
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://v.juhe.cn/weather/index?cityname=%@&key=54e034cb611851105353c483c9a0fc8a",_id.city_id]]];
    request.delegate = self;
    [request startAsynchronous];
}

- (void)weathercity{
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://apis.baidu.com/heweather/weather/free?city=beijing&apikey=f551c2ee57aea654958c5786ed4f88ec"]]];
    request.delegate = self;
    [request startAsynchronous];

}

- (void)movie{
    //    NSString *cityname = @"上海";
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://v.juhe.cn/boxoffice/rank.php?key=1da45eade47abec4200b8b4f9d8be12f&area=CN"]]];
    request.delegate = self;
    [request startAsynchronous];
    

}
- (void)requestFinished:(ASIHTTPRequest *)request

{
    
    // 当以文本形式读取返回内容时用这个方法
    
    NSString *responseString = [request responseString];
    NSLog(@"nsstring==%@",responseString);
    
    
    // 当以二进制形式读取返回内容时用这个方法
    
    NSData *responseData = [request responseData];
    NSLog(@"nadata==%@",responseData);
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
        NSLog(@"dic= %@",dic);
        NSArray *dic2 = [dic valueForKey:@"result"];
    for (NSDictionary *dic_w in dic2) {
        if ([[dic_w valueForKey:@"province"] isEqualToString:@"北京"] && [[dic_w valueForKey:@"city"] isEqualToString:@"北京"] && [[dic_w valueForKey:@"district"] isEqualToString:@"顺义"]) {
            NSLog(@"%@",[dic_w valueForKey:@"id"]);
                    IdModel *_id = [IdModel initObjectID];
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100.0f, 100.0f, 50.0f, 30.0f)];
            btn.backgroundColor = [UIColor blackColor];
            [btn setTitle:@"Send" forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btn];
            
            _id.city_id = [dic_w valueForKey:@"id"];
          
    }

    }


    
    
    
//    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
//    NSLog(@"dic= %@",dic);
//    NSArray *dic2 = [dic valueForKey:@"result"];
//    
//    for (NSDictionary * dic_m in dic2) {
//        NSLog(@"%@",dic_m[@"name"]);
//    }
    
//    NSData *newname = [dic2 valueForKey:@"name"];
//    NSLog(@"%@",newname);
    // 问题出现在这里 只要一解码 就回crash
//    NSString *name = [[NSString alloc] initWithData:newname  encoding:NSUTF8StringEncoding];
//    NSLog(@"%@",name);

}
- (void)click{
    SecViewController * VC=[[SecViewController alloc]init];
    [self presentViewController:VC animated:YES completion:^{
    NSLog(@"present成功，从ViewController切换到FirstViewController");//此方法调用了会执行这行代码
    }];

}
- (void)requestFailed:(ASIHTTPRequest *)request

{
    
    NSError *error = [request error];
    NSLog(@"%@",error);
}

@end
