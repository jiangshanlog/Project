//
//  IdModel.h
//  天气预报接口1.0
//
//  Created by QG on 15/12/30.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IdModel : NSObject
@property (nonatomic,weak)NSString *city_id;
+(id)initObjectID;
@end
