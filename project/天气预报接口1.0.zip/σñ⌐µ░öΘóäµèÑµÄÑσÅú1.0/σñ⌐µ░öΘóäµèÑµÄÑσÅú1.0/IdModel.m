//
//  IdModel.m
//  天气预报接口1.0
//
//  Created by QG on 15/12/30.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "IdModel.h"

@implementation IdModel
+(id)initObjectID{
    static IdModel *oper;
    if(oper == nil){
        oper=[[IdModel alloc]init];
    }
    
    return oper;
}
@end
