//
//  SecViewController.m
//  天气预报接口1.0
//
//  Created by QG on 15/12/30.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "SecViewController.h"
#import "IdModel.h"
#import <ASIHTTPRequest/ASIHTTPRequest.h>
@interface SecViewController ()

@end

@implementation SecViewController
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.view.backgroundColor = [UIColor whiteColor];
IdModel *_id = [IdModel initObjectID];
    NSLog(@"%@",_id.city_id);
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    IdModel *_id = [IdModel initObjectID];
    NSLog(@"%@",_id.city_id);
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://v.juhe.cn/weather/index?cityname=%@&key=54e034cb611851105353c483c9a0fc8a",_id.city_id]]];
    request.delegate = self;
    [request startAsynchronous];
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    
    // 当以文本形式读取返回内容时用这个方法
    
    NSString *responseString = [request responseString];
    NSLog(@"nsstring==%@",responseString);
    
    
    // 当以二进制形式读取返回内容时用这个方法
    
    NSData *responseData = [request responseData];
    NSLog(@"nadata==%@",responseData);


}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
