//
//  TableViewController.m
//  2030APITestDemo
//
//  Created by QG on 16/2/1.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "TableViewController.h"
#import "TableViewCell.h"
#import "Model.h"
@interface TableViewController ()
{
    NSArray *mobans;
}
@property(nonatomic,strong)NSMutableArray *modelArray;
@property(nonatomic,strong)Model *model;
@end

@implementation TableViewController
- (void)viewWillAppear:(BOOL)animated{


}
-(NSMutableArray *)modelArray{
    if (_modelArray ==nil) {
        self.modelArray = [NSMutableArray array];
    }
    return _modelArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
        [self test];
       mobans = [[NSArray alloc]init];
    
    _model = [Model shareInstance];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _model.chname.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *str=@"cell";
    TableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];

        cell=[[[NSBundle mainBundle]loadNibNamed:@"TableViewCell" owner:self options:nil]lastObject];

//    _model = [Model initWithModel];
    NSLog(@"array = %@",_model.chname);

                   cell.chname.text = _model.chname[indexPath.row];



    cell.desc.text = _model.desc[indexPath.row];
    
    cell.did.text = _model.did[indexPath.row];
    cell.type.text = _model.type[indexPath.row];
    cell.image.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_model.image[indexPath.row]]]];
    cell.smallimage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_model.smallimage[indexPath.row]]]];
    
    return cell;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 140;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)test{
    NSString *urlstr = @"http://2030api.715buy.com/api?act=216&v=1.0.0&sys=android&sign=4b6ae0759ef2b77cbf4697e588b1848b&strtime=1453866834&param={\"uid\":\"179\",\"mob_type\":\"601\"}";
    urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:urlstr];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *datatask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //        NSString *dataStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        ////        NSLog(@"data: %@", dataStr);
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSDictionary *resultdic = [dic valueForKey:@"result"];
        mobans = [resultdic valueForKey:@"mobans"];
//        Model *model = [Model initWithModel];
        _model.chname = [NSMutableArray array];
        _model.desc = [NSMutableArray array];
        _model.did = [NSMutableArray array];
        _model.type = [NSMutableArray array];
        _model.image = [NSMutableArray array];
        _model.smallimage = [NSMutableArray array];
        for (NSDictionary *finaldic in mobans) {
            NSLog(@"%@",finaldic);
//            [_model setValue:[finaldic valueForKey:@"chname"] forKey:@"chname"];
//            _model.chname = [finaldic valueForKey:@"chname"];
            [_model.chname addObject:[finaldic valueForKey:@"chname"]];
            [_model.desc addObject:[finaldic valueForKey:@"desc"]];
            [_model.did addObject:[finaldic valueForKey:@"mob_id"]];
            [_model.type addObject:[finaldic valueForKey:@"mob_type"]];
            [_model.image addObject:[finaldic valueForKey:@"imageurl"]];
            [_model.smallimage addObject:[finaldic valueForKey:@"thumbnailurl"]];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
        
        
    }];

    [datatask resume];


}

@end
