//
//  Model.m
//  2030APITestDemo
//
//  Created by QG on 16/2/1.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "Model.h"

@implementation Model

+ (instancetype)shareInstance {
    static Model *m = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        m = [[Model alloc] init];
    });
    return m;
}

//+(id)initWithModel{
//    static Model *model;
//    if (model==nil) {
//        //只初始化一次
//        model = [[Model alloc]init];
//    }
//    return model;
//}
//- (void)setValue:(id)value forUndefinedKey:(NSString *)key
//{
//
//}
@end
