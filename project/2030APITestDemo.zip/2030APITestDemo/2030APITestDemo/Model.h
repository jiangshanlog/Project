//
//  Model.h
//  2030APITestDemo
//
//  Created by QG on 16/2/1.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject
@property (nonatomic,strong)NSMutableArray *chname;
@property (nonatomic,strong)NSMutableArray *smallimage;
@property (nonatomic,strong)NSMutableArray *desc;
@property (nonatomic,strong)NSMutableArray *image;
@property (nonatomic,strong)NSMutableArray *did;
@property (nonatomic,strong)NSMutableArray *type;
//@property (nonatomic,copy)NSArray *array;
+ (instancetype)shareInstance;
@end
