//
//  Model.h
//  二维码扫描
//
//  Created by 姜杉 on 16/3/31.
//  Copyright © 2016年 姜杉. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject
@property (nonatomic ,copy)NSString *Result;
+(id)initWithnumber;
@end
