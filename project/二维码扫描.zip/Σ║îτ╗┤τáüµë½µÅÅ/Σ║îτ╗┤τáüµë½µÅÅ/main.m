//
//  main.m
//  二维码扫描
//
//  Created by 姜杉 on 16/3/31.
//  Copyright © 2016年 姜杉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
