//
//  AppDelegate.h
//  plist动态写入
//
//  Created by QG on 16/1/12.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

