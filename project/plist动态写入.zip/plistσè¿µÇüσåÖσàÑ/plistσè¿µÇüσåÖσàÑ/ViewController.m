//
//  ViewController.m
//  plist动态写入
//
//  Created by QG on 16/1/12.
//  Copyright © 2016年 Johnson. All rights reserved.
//

#import "ViewController.h"
#import "JHAPISDK.h"
#import "JHOpenidSupplier.h"
@interface ViewController (){
    NSDictionary* dic;
    NSDictionary *dic12;

}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];


    NSMutableArray *cityarray = [NSMutableArray array];
    NSMutableArray *idarray = [NSMutableArray array];
    NSMutableArray *bigcityarray = [NSMutableArray array];


    //1. 创建一个plist文件
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path1=[paths    objectAtIndex:0];
    NSLog(@"path1 = %@",path1);
    NSString *filename=[path1 stringByAppendingPathComponent:@"citynumber.plist"];
    NSFileManager* fm = [NSFileManager defaultManager];
    [fm createFileAtPath:filename contents:nil attributes:nil];
    //NSDictionary* dic = [NSDictionary dictionaryWithContentsOfFile:plistPath];
    

    

    
                                       //创建一个dic，写到plist文件里
                                    dic = [NSDictionary dictionaryWithObjectsAndKeys:cityarray,@"cityname",nil];

                                        [dic writeToFile:filename atomically:YES];
                                        //读文件
                                        NSDictionary* dic2 = [NSDictionary dictionaryWithContentsOfFile:filename];
                                        NSLog(@"dic is:%@",dic2);
                                    
//                                    NSLog(@"dic ======= %@",dic);

                                }



    


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
