//
//  ViewController.m
//  GPSdemo
//
//  Created by QG on 15/12/31.
//  Copyright © 2015年 Johnson. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <ASIHTTPRequest/ASIHTTPRequest.h>
@interface ViewController ()<CLLocationManagerDelegate>{
    double latitude;
    double longitude;
}
@property (nonatomic, retain) CLLocationManager* locationMgr;
@property (nonatomic, retain) CLGeocoder* clGeocoder;
//@property(nonatomic,strong)CLGeocoder *geocoder;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.locationMgr = [[CLLocationManager alloc] init];
    
    //设置代理
    self.locationMgr.delegate = self;
    
    // 设置定位精度
    // kCLLocationAccuracyNearestTenMeters:精度10米
    // kCLLocationAccuracyHundredMeters:精度100 米
    // kCLLocationAccuracyKilometer:精度1000 米
    // kCLLocationAccuracyThreeKilometers:精度3000米
    // kCLLocationAccuracyBest:设备使用电池供电时候最高的精度
    // kCLLocationAccuracyBestForNavigation:导航情况下最高精度，一般要有外接电源时才能使用
    self.locationMgr.desiredAccuracy = kCLLocationAccuracyBest;
    
    // distanceFilter是距离过滤器，为了减少对定位装置的轮询次数，位置的改变不会每次都去通知委托，而是在移动了足够的距离时才通知委托程序
    // 它的单位是米，这里设置为至少移动1000再通知委托处理更新;
    self.locationMgr.distanceFilter = 1000.0f;
    if ([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0) {
        [self.locationMgr requestAlwaysAuthorization];
    }
    //开始定位
    [self.locationMgr startUpdatingLocation];
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100.0f, 100.0f, 50.0f, 30.0f)];
    btn.backgroundColor = [UIColor blackColor];
    [btn setTitle:@"Send" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

}
- (void)click{

    
    NSLog(@"11纬度--%f",latitude);
    NSLog(@"11经度--%f",longitude);
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://v.juhe.cn/weather/geo?format=2&key=54e034cb611851105353c483c9a0fc8a&lon=%f&lat=%f",longitude,latitude]]];
    request.delegate = self;
    [request startAsynchronous];
    

}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    
    // 当以文本形式读取返回内容时用这个方法
    
    NSString *responseString = [request responseString];
    NSLog(@"nsstring==%@",responseString);
    
    
    // 当以二进制形式读取返回内容时用这个方法
    
    NSData *responseData = [request responseData];
    NSLog(@"nadata==%@",responseData);
    
    
}




-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *cl = [locations objectAtIndex:0];
    latitude = cl.coordinate.latitude;
    longitude = cl.coordinate.longitude;
    NSLog(@"纬度--%f",latitude);
    NSLog(@"经度--%f",longitude);
    
}


//获取定位失败回调方法
#pragma mark - location Delegate
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"Location error!");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)weather{


}
//- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
//{
//[self.geocoder reverseGeocodeLocation:userLocation.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
//    CLPlacemark *sss = [placemarks firstObject];
//    userLocation.title = sss.name;
//    userLocation.subtitle = sss.locality;
//    NSLog(@"%@,%@",sss.name,sss.locality);
//}];
//
//}
@end
